﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class ThrowRod : MonoBehaviour
{
    public GameObject cube;
    public GameObject ball;
    public bool isThrown = false;
    private bool isFishCome = false;
    private float time;
    public int fish_num = 0;
    private float remain_time = 0f;
    private Sequence sequence = DOTween.Sequence();
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            if (isFishCome)
            {
                isFishCome = false;
                Debug.Log("you catch fish!");
                fish_num++;
                sequence.Complete();
                ball.GetComponent<ThrowBall>().StopShakingBall();
            }
            isThrown = !isThrown;
            cube.GetComponent<ThrowCube>().ChangeCube(isThrown);
            ball.GetComponent<ThrowBall>().ChangeBall(isThrown);
            if (isThrown)
            {
                time = Random.Range(3.0f, 7.0f);
                /*sequence.AppendInterval(time);
                sequence.AppendCallback(BallShake);
                sequence.Append(ball.transform.DOShakePosition(2.0f, 0.2f));
                sequence.AppendCallback(FishEscape);*/

                Invoke("BallShake", time);
                //Invoke("FishEscape", time);
            }
        }
    }

    private void BallShake()
    {
        if (isThrown)
        {
            Invoke("FishEscape", 2.0f);
            Debug.Log("fish come");
            isFishCome = true;
            ball.GetComponent<ThrowBall>().ShakeBall();
        }
    }
    private void FishEscape()
    {
        if (isThrown&isFishCome)
        {
            Debug.Log("fish escape");
            isFishCome = false;
        }
    }
}
